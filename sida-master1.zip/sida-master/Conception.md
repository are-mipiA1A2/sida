Système 
-> agents:

- attributs:
sexualité (homosexuel, hétérosexuel, bisexuel), genre (homme, femme), niveau de vie (seuil de pauvreté), contraception 

- procédures:
rapport sexuelle (anal, vaginal), rapport sanguin


Environnement

- variables:
http://vih.org/20171129/vih-en-france-en-2017/139817
- CAS DE DECOUVERTES PAR AN DE SIDA DANS LES DIFFERENTES REGIONS FRANCAISE

- Ile-De-France (206/milion) -> 2472
- Haut de France (49) ->294
- Grand Est (53)->295
- Noramndie (44)->154
- Bretagne (28)->130
- Pays de la Loire (47)->175
- Centre Val de Loire (48)->125
- Bourgogne Franche Comté (37)->104
- Nouvelle Aquitaine (45)->266
- Auvergne Rhone Alpes (61)->476
- Occitanie (77)->439
- Provence Alpes Cote d'Azur (74)->370
- Corse (3)->1
- Guaeloupe (238)->96
- Martinique (172)->65
- Guyane (907)->227
- Reunion (43)->36
- Mayotte (183)->471






  : lieu de naissance :
- nés à l'étranger : hommes hétéros --> 15%
                      femmes hétéros --> 23%
- nés en France : hommes hétéros --> 9%
                  femmes hétéros --> 7%
